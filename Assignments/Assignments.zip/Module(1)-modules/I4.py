# Aim: Write a Python program to calculate the area of a parallelogram.

try:
	base = float(input('Length of base: '))
	height = float(input('Measurement of height: '))
	area = base * height
	print("Area is: ", area)
except:
	print("Invalid input.")