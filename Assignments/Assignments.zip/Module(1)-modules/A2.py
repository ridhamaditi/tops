# Aim: Write a Python program to get the square root and exponential of a given decimal number.

from math import sqrt, exp
x = float(input('Enter number:'))
print("Square root of ",x, " is :", sqrt(x))
print("exponential of ",x, " is :", exp(x))